# Better Tomorrow — Version 2 Play AAB

This package contains the verified Android source for `com.bettertomorrow.app` with versionCode 2 / versionName 1.0.1 and a workflow designed to build the signed Play upload AAB from the package ZIP.

Required GitHub Actions secrets:
- BT_UPLOAD_KEYSTORE_B64
- BT_UPLOAD_KEY_ALIAS
- BT_UPLOAD_KEY_PASSWORD
- BT_UPLOAD_STORE_PASSWORD

Run only `Better Tomorrow - Version 2 Play AAB` after the source ZIP is present in the repository root.
