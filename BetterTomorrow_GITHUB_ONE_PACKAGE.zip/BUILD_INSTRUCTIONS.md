# Better Tomorrow — Version 2 Play Store build

This project is configured for a **signed release AAB** with:
- applicationId: `com.bettertomorrow.app`
- versionCode: `2`
- versionName: `1.0.1`

## GitHub Actions build

The workflow is `.github/workflows/build-release-aab.yml`. It builds `app-release.aab` and publishes it as a GitHub Actions artifact.

Before running the workflow, create these **Repository secrets** using the newly approved upload key:

- `BT_UPLOAD_KEYSTORE_B64` — base64 contents of `bettertomorrow-upload-key.jks`
- `BT_UPLOAD_KEY_ALIAS` — `bettertomorrow-upload`
- `BT_UPLOAD_KEY_PASSWORD` — the private key password
- `BT_UPLOAD_STORE_PASSWORD` — the keystore password

Never commit the `.jks` file or passwords to the repository.

After the reset is approved, the Play Console upload-key certificate SHA-256 should match the new certificate before uploading the AAB.
