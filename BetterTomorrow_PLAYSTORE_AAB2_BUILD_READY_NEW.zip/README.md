# Better Tomorrow — Play Store Version 2 Build Source

This project is prepared for a Google Play Console-compatible Version 2 Android App Bundle (AAB).

## App identity
- Application ID: `com.bettertomorrow.app`
- Version Code: `2`
- Version Name: `1.0.1`
- Compile/Target SDK: 36
- Minimum SDK: 24

## GitHub Actions signing secrets
Create these repository secrets exactly:

- `BT_UPLOAD_KEYSTORE_B64`
- `BT_UPLOAD_KEY_ALIAS`
- `BT_UPLOAD_KEY_PASSWORD`
- `BT_UPLOAD_STORE_PASSWORD`

The workflow uses the Play upload keystore supplied through `BT_UPLOAD_KEYSTORE_B64`. Do not commit the `.jks` file or any password.

## Build
Open GitHub → Actions → **Better Tomorrow - Release AAB** → **Run workflow**.

The workflow:
1. Restores the upload keystore from the Base64 secret.
2. Builds `versionCode 2` / `versionName 1.0.1`.
3. Verifies the AAB signature.
4. Verifies that the AAB signer certificate matches the configured upload keystore.
5. Publishes the AAB as the `BetterTomorrow-release-v2-AAB` artifact.

## Important
The AAB certificate must correspond to the upload certificate currently registered in Google Play Console. The workflow can prove that the AAB matches the configured keystore; Play Console remains the final authority on whether that certificate is the registered upload key.
